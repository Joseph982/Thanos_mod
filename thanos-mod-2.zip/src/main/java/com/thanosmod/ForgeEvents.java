package com.thanosmod;

import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = ThanosMod.MODID)
public class ForgeEvents {
    /** A worthy Mjolnir holder (and the gauntlet holder) is immune to lightning. */
    @SubscribeEvent
    public static void onAttacked(LivingAttackEvent event) {
        if (event.getEntity() instanceof Player player && event.getSource().is(DamageTypeTags.IS_LIGHTNING)) {
            boolean mjolnir = player.getMainHandItem().getItem() instanceof MjolnirItem && MjolnirItem.isWorthy(player);
            boolean gauntlet = player.getMainHandItem().getItem() instanceof InfinityGauntletItem;
            if (mjolnir || gauntlet) {
                event.setCanceled(true);
            }
        }
    }
}
