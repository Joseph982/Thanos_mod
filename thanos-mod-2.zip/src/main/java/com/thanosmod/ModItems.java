package com.thanosmod;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.EnumMap;
import java.util.Map;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, ThanosMod.MODID);
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, ThanosMod.MODID);

    public static final Map<Stone, RegistryObject<Item>> STONES = new EnumMap<>(Stone.class);

    static {
        for (Stone stone : Stone.values()) {
            STONES.put(stone, ITEMS.register(stone.id + "_stone",
                    () -> new StoneItem(stone, new Item.Properties()
                            .stacksTo(1).rarity(Rarity.EPIC).fireResistant())));
        }
    }

    public static final RegistryObject<Item> GAUNTLET = ITEMS.register("infinity_gauntlet",
            () -> new InfinityGauntletItem(new Item.Properties()
                    .stacksTo(1).rarity(Rarity.EPIC).fireResistant()));

    public static final RegistryObject<Item> MJOLNIR = ITEMS.register("mjolnir",
            () -> new MjolnirItem(new Item.Properties()
                    .stacksTo(1).rarity(Rarity.EPIC).fireResistant()));

    public static final RegistryObject<Item> THOR_SPAWN_EGG = ITEMS.register("thor_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.THOR, 0xE8C547, 0x3A7BD5, new Item.Properties()));

    public static final RegistryObject<CreativeModeTab> TAB = TABS.register("thanos_tab",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.thanosmod"))
                    .icon(() -> new ItemStack(GAUNTLET.get()))
                    .displayItems((params, output) -> {
                        output.accept(GAUNTLET.get());
                        for (Stone stone : Stone.values()) {
                            output.accept(stone.item());
                        }
                        output.accept(MJOLNIR.get());
                        output.accept(THOR_SPAWN_EGG.get());
                    })
                    .build());

    public static void register(IEventBus bus) {
        ITEMS.register(bus);
        TABS.register(bus);
    }
}
