package com.thanosmod;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, ThanosMod.MODID);

    public static final RegistryObject<EntityType<ThorEntity>> THOR = ENTITIES.register("thor",
            () -> EntityType.Builder.<ThorEntity>of(ThorEntity::new, MobCategory.MONSTER)
                    .sized(0.72F, 2.34F)
                    .clientTrackingRange(10)
                    .fireImmune()
                    .build("thor"));
}
