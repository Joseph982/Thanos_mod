package com.thanosmod;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.boss.enderdragon.EnderDragon;
import net.minecraft.world.entity.boss.wither.WitherBoss;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * The Infinity Gauntlet.
 *
 * Controls: HOLD right-click to charge, release to fire.
 *   - quick tap (under 1 second) = the stone's quick power
 *   - hold 1 second or more      = the stone's ultimate power
 *   - Shift + right-click        = switch stone
 *   - put a stone in your OFF-HAND to pick it instantly (no switching)
 *   - last mode = THE SNAP, needs all six stones and a 3 second charge
 * Stones must be in your inventory. While you hold the gauntlet, every stone you
 * carry also gives a small passive buff.
 */
public class InfinityGauntletItem extends Item {
    private static final String MODE_KEY = "Mode";
    private static final int SNAP_MODE = Stone.values().length;
    private static final int CHARGED_AT = 20;
    private static final int SNAP_CHARGE = 60;
    private static final int MAX_USE = 72000;

    private static final EntityType<?>[] CALM_POOL = {
            EntityType.COW, EntityType.PIG, EntityType.SHEEP,
            EntityType.CHICKEN, EntityType.RABBIT, EntityType.FOX};

    private static final Block[] CHAOS_BLOCKS = {
            Blocks.DIAMOND_BLOCK, Blocks.GOLD_BLOCK, Blocks.EMERALD_BLOCK, Blocks.AMETHYST_BLOCK,
            Blocks.OBSIDIAN, Blocks.GLASS, Blocks.MAGMA_BLOCK, Blocks.SLIME_BLOCK,
            Blocks.HONEY_BLOCK, Blocks.PURPUR_BLOCK};

    /** Where each player was over the last few seconds (used by Time's rewind). */
    private static final Map<UUID, ArrayDeque<Snapshot>> HISTORY = new HashMap<>();

    private record Snapshot(ResourceKey<Level> dimension, double x, double y, double z,
                            float yRot, float xRot, float health) {
    }

    public InfinityGauntletItem(Properties properties) {
        super(properties);
    }

    // ---------- modes ----------

    private static int getMode(ItemStack stack) {
        return stack.getOrCreateTag().getInt(MODE_KEY) % (SNAP_MODE + 1);
    }

    private static int effectiveMode(Player player, ItemStack gauntlet, InteractionHand hand) {
        if (hand == InteractionHand.MAIN_HAND && player.getOffhandItem().getItem() instanceof StoneItem stoneItem) {
            return stoneItem.getStone().ordinal();
        }
        return getMode(gauntlet);
    }

    private static Component modeName(int mode) {
        if (mode == SNAP_MODE) {
            return Component.translatable("mode.thanosmod.snap").withStyle(ChatFormatting.DARK_RED);
        }
        return Stone.values()[mode].displayName();
    }

    private static boolean hasStone(Player player, Stone stone) {
        Item item = stone.item();
        Inventory inv = player.getInventory();
        for (int i = 0; i < inv.getContainerSize(); i++) {
            if (inv.getItem(i).is(item)) {
                return true;
            }
        }
        return false;
    }

    private static boolean hasAllStones(Player player) {
        for (Stone stone : Stone.values()) {
            if (!hasStone(player, stone)) {
                return false;
            }
        }
        return true;
    }

    private static Component problemFor(Player player, int mode) {
        if (mode == SNAP_MODE) {
            return hasAllStones(player) ? null
                    : Component.translatable("message.thanosmod.need_all").withStyle(ChatFormatting.RED);
        }
        Stone stone = Stone.values()[mode];
        return hasStone(player, stone) ? null
                : Component.translatable("message.thanosmod.need_stone", stone.displayName()).withStyle(ChatFormatting.RED);
    }

    /** Things the gauntlet will not touch: bosses, Thor, pets, name-tagged mobs, players. */
    public static boolean isSpared(Entity e) {
        return e instanceof Player
                || e instanceof EnderDragon
                || e instanceof WitherBoss
                || e instanceof ThorEntity
                || e.hasCustomName()
                || (e instanceof TamableAnimal pet && pet.isTame());
    }

    // ---------- item behaviour ----------

    @Override
    public boolean isFoil(ItemStack stack) {
        return true;
    }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.thanosmod.mode", modeName(getMode(stack))).withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable("tooltip.thanosmod.gauntlet_hint1").withStyle(ChatFormatting.DARK_GRAY));
        tooltip.add(Component.translatable("tooltip.thanosmod.gauntlet_hint2").withStyle(ChatFormatting.DARK_GRAY));
        tooltip.add(Component.translatable("tooltip.thanosmod.gauntlet_hint3").withStyle(ChatFormatting.DARK_GRAY));
    }

    @Override
    public UseAnim getUseAnimation(ItemStack stack) {
        return UseAnim.BOW;
    }

    @Override
    public int getUseDuration(ItemStack stack) {
        return MAX_USE;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack gauntlet = player.getItemInHand(hand);

        if (player.isShiftKeyDown()) {
            if (!level.isClientSide) {
                int next = (getMode(gauntlet) + 1) % (SNAP_MODE + 1);
                gauntlet.getOrCreateTag().putInt(MODE_KEY, next);
                player.displayClientMessage(modeName(next), true);
            }
            return InteractionResultHolder.sidedSuccess(gauntlet, level.isClientSide);
        }

        int mode = effectiveMode(player, gauntlet, hand);
        Component problem = problemFor(player, mode);
        if (problem != null) {
            if (!level.isClientSide) {
                player.displayClientMessage(problem, true);
            }
            return InteractionResultHolder.fail(gauntlet);
        }
        player.startUsingItem(hand);
        return InteractionResultHolder.consume(gauntlet);
    }

    @Override
    public void inventoryTick(ItemStack stack, Level level, Entity entity, int slot, boolean selected) {
        super.inventoryTick(stack, level, entity, slot, selected);
        if (level.isClientSide || !(entity instanceof ServerPlayer player)) {
            return;
        }
        if (player.tickCount % 10 == 0) {
            ArrayDeque<Snapshot> history = HISTORY.computeIfAbsent(player.getUUID(), k -> new ArrayDeque<>());
            history.addLast(new Snapshot(player.level().dimension(), player.getX(), player.getY(), player.getZ(),
                    player.getYRot(), player.getXRot(), player.getHealth()));
            while (history.size() > 12) {
                history.removeFirst();
            }
        }
        if (selected && player.tickCount % 20 == 0) {
            for (Stone stone : Stone.values()) {
                if (hasStone(player, stone)) {
                    MobEffect buff = switch (stone) {
                        case SPACE -> MobEffects.JUMP;
                        case MIND -> MobEffects.NIGHT_VISION;
                        case REALITY -> MobEffects.LUCK;
                        case POWER -> MobEffects.DAMAGE_BOOST;
                        case SOUL -> MobEffects.ABSORPTION;
                        case TIME -> MobEffects.MOVEMENT_SPEED;
                    };
                    player.addEffect(new MobEffectInstance(buff, 260, 0, true, false));
                }
            }
        }
    }

    @Override
    public void onUseTick(Level level, LivingEntity living, ItemStack stack, int remaining) {
        if (level.isClientSide || !(living instanceof ServerPlayer player)) {
            return;
        }
        ServerLevel server = (ServerLevel) level;
        int charge = getUseDuration(stack) - remaining;
        int mode = effectiveMode(player, stack, player.getUsedItemHand());

        if (mode == SNAP_MODE) {
            // six coloured streams spiral up around you as the Snap charges
            double progress = Math.min(1.0D, charge / (double) SNAP_CHARGE);
            for (Stone stone : Stone.values()) {
                double angle = charge * 0.35D + stone.ordinal() * Math.PI / 3.0D;
                double radius = 1.7D - progress * 0.9D;
                Vec3 pos = player.position().add(Math.cos(angle) * radius, 0.2D + progress * 1.8D, Math.sin(angle) * radius);
                server.sendParticles(Fx.dust(stone.rgb, 1.4F), pos.x, pos.y, pos.z, 1, 0.0D, 0.0D, 0.0D, 0.0D);
            }
            if (charge % 10 == 0 && charge <= SNAP_CHARGE) {
                player.displayClientMessage(Component.translatable("message.thanosmod.snap_charge", (int) (progress * 100))
                        .withStyle(ChatFormatting.GOLD), true);
            }
            if (charge == SNAP_CHARGE) {
                Fx.sound(server, player.position(), SoundEvents.BEACON_POWER_SELECT, 2.0F, 0.8F);
            }
            return;
        }

        Stone stone = Stone.values()[mode];
        if (charge < CHARGED_AT) {
            if (charge % 2 == 0) {
                Fx.ring(server, player.position().add(0.0D, 1.0D, 0.0D), 0.4D + charge * 0.05D, stone.rgb, 8);
            }
        } else {
            if (charge == CHARGED_AT) {
                Fx.sound(server, player.position(), SoundEvents.EXPERIENCE_ORB_PICKUP, 1.5F, 1.2F);
                player.displayClientMessage(Component.translatable("message.thanosmod.charged").withStyle(stone.color), true);
            }
            if (charge % 3 == 0) {
                Fx.ring(server, player.position().add(0.0D, 0.1D + (charge % 12) * 0.15D, 0.0D), 1.2D, stone.rgb, 14);
            }
        }
    }

    @Override
    public void releaseUsing(ItemStack stack, Level level, LivingEntity living, int timeLeft) {
        if (level.isClientSide || !(living instanceof ServerPlayer player)) {
            return;
        }
        ServerLevel server = (ServerLevel) level;
        int charge = getUseDuration(stack) - timeLeft;
        int mode = effectiveMode(player, stack, player.getUsedItemHand());

        Component problem = problemFor(player, mode);
        if (problem != null) {
            player.displayClientMessage(problem, true);
            return;
        }

        if (mode == SNAP_MODE) {
            if (charge < SNAP_CHARGE) {
                player.displayClientMessage(Component.translatable("message.thanosmod.snap_interrupted")
                        .withStyle(ChatFormatting.GRAY), true);
                return;
            }
            if (!snap(server, player)) {
                player.displayClientMessage(Component.translatable("message.thanosmod.snap_empty")
                        .withStyle(ChatFormatting.GRAY), true);
            }
            return;
        }

        Stone stone = Stone.values()[mode];
        boolean charged = charge >= CHARGED_AT;
        boolean used = switch (stone) {
            case SPACE -> charged ? spaceSingularity(server, player) : spaceTeleport(server, player);
            case MIND -> charged ? mindDominion(server, player) : mindConfuse(server, player);
            case REALITY -> charged ? realityRewrite(server, player) : realityTransform(server, player);
            case POWER -> charged ? powerAnnihilation(server, player) : powerBlast(server, player);
            case SOUL -> charged ? soulDrain(server, player) : soulHeal(server, player);
            case TIME -> charged ? timeRewind(server, player) : timeStasis(server, player);
        };
        if (used) {
            player.getCooldowns().addCooldown(this, charged ? 120 : 25);
        } else {
            player.displayClientMessage(Component.translatable("message.thanosmod.nothing")
                    .withStyle(ChatFormatting.GRAY), true);
        }
    }

    // =====================================================================
    // SPACE
    // =====================================================================

    /** Tap: teleport to where you look (up to 64 blocks). */
    private boolean spaceTeleport(ServerLevel level, ServerPlayer player) {
        HitResult hit = player.pick(64.0D, 1.0F, false);
        BlockPos base;
        if (hit instanceof BlockHitResult block && hit.getType() == HitResult.Type.BLOCK) {
            base = block.getBlockPos().relative(block.getDirection());
        } else {
            base = BlockPos.containing(hit.getLocation());
        }
        Vec3 dest = new Vec3(base.getX() + 0.5D, base.getY(), base.getZ() + 0.5D);
        for (int i = 0; i < 3; i++) {
            Vec3 delta = dest.subtract(player.position());
            if (level.noCollision(player, player.getBoundingBox().move(delta))) {
                break;
            }
            dest = dest.add(0.0D, 1.0D, 0.0D);
        }
        Fx.ring(level, player.position().add(0.0D, 0.1D, 0.0D), 1.0D, Stone.SPACE.rgb, 20);
        Fx.burst(level, player.position().add(0.0D, 1.0D, 0.0D), Stone.SPACE.rgb, 40, 0.5D);
        Fx.sound(level, player.position(), SoundEvents.ENDERMAN_TELEPORT, 1.0F, 1.0F);
        player.connection.teleport(dest.x, dest.y, dest.z, player.getYRot(), player.getXRot());
        player.fallDistance = 0.0F;
        Fx.ring(level, dest.add(0.0D, 0.1D, 0.0D), 1.0D, Stone.SPACE.rgb, 20);
        Fx.burst(level, dest.add(0.0D, 1.0D, 0.0D), Stone.SPACE.rgb, 40, 0.5D);
        Fx.sound(level, dest, SoundEvents.ENDERMAN_TELEPORT, 1.0F, 1.0F);
        return true;
    }

    /** Charged: a singularity pulls everything nearby into one point and crushes it. */
    private boolean spaceSingularity(ServerLevel level, ServerPlayer player) {
        Vec3 point = player.pick(30.0D, 1.0F, false).getLocation();
        AABB area = new AABB(point, point).inflate(24.0D);
        List<LivingEntity> victims = level.getEntitiesOfClass(LivingEntity.class, area, e -> !isSpared(e));
        if (victims.isEmpty()) {
            return false;
        }
        for (LivingEntity e : victims) {
            Vec3 pull = point.subtract(e.position());
            double speed = Math.min(2.0D, pull.length() * 0.3D + 0.6D);
            e.setDeltaMovement(pull.normalize().scale(speed).add(0.0D, 0.2D, 0.0D));
            e.hurtMarked = true;
        }
        for (int r = 6; r >= 1; r--) {
            final int radius = r;
            Scheduler.later((6 - r) * 2 + 1, () -> Fx.ring(level, point.add(0.0D, 0.3D, 0.0D), radius, Stone.SPACE.rgb, radius * 8));
        }
        Fx.sound(level, point, SoundEvents.ENDER_DRAGON_GROWL, 1.5F, 1.4F);
        Scheduler.later(14, () -> {
            for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, new AABB(point, point).inflate(5.0D), x -> !isSpared(x))) {
                e.hurt(level.damageSources().playerAttack(player), 12.0F);
            }
            Fx.burst(level, point.add(0.0D, 0.5D, 0.0D), Stone.SPACE.rgb, 120, 1.5D);
            level.sendParticles(ParticleTypes.EXPLOSION_EMITTER, point.x, point.y + 0.5D, point.z, 1, 0.0D, 0.0D, 0.0D, 0.0D);
            Fx.sound(level, point, SoundEvents.GENERIC_EXPLODE, 2.0F, 0.8F);
        });
        return true;
    }

    // =====================================================================
    // MIND
    // =====================================================================

    /** Tap: nearby mobs turn on each other for 8 seconds. */
    private boolean mindConfuse(ServerLevel level, ServerPlayer player) {
        List<Mob> mobs = level.getEntitiesOfClass(Mob.class, player.getBoundingBox().inflate(20.0D), m -> !isSpared(m));
        if (mobs.size() < 2) {
            return false;
        }
        for (Mob mob : mobs) {
            mob.addEffect(new MobEffectInstance(ModEffects.MIND_CONTROL.get(), 160, 0));
            mob.addEffect(new MobEffectInstance(MobEffects.GLOWING, 160, 0));
        }
        Fx.ring(level, player.position().add(0.0D, 1.0D, 0.0D), 3.0D, Stone.MIND.rgb, 30);
        Fx.sound(level, player.position(), SoundEvents.EVOKER_CAST_SPELL, 1.0F, 1.0F);
        return true;
    }

    /** Charged: a psychic wave takes over every mob within 30 blocks for 20 seconds. */
    private boolean mindDominion(ServerLevel level, ServerPlayer player) {
        List<Mob> mobs = level.getEntitiesOfClass(Mob.class, player.getBoundingBox().inflate(30.0D), m -> !isSpared(m));
        if (mobs.isEmpty()) {
            return false;
        }
        for (Mob mob : mobs) {
            mob.addEffect(new MobEffectInstance(ModEffects.MIND_CONTROL.get(), 400, 0));
            mob.addEffect(new MobEffectInstance(MobEffects.GLOWING, 400, 0));
            if (mob.getTarget() == player) {
                mob.setTarget(null);
            }
        }
        Vec3 origin = player.position().add(0.0D, 0.3D, 0.0D);
        for (int r = 3; r <= 30; r += 3) {
            final int radius = r;
            Scheduler.later(radius / 2, () -> Fx.ring(level, origin, radius, Stone.MIND.rgb, radius * 6));
        }
        Fx.sound(level, player.position(), SoundEvents.EVOKER_PREPARE_SUMMON, 2.0F, 0.8F);
        return true;
    }

    // =====================================================================
    // REALITY
    // =====================================================================

    /** Rewrites every mob in range into a random calm animal. Returns how many changed. */
    private int rewriteMobs(ServerLevel level, ServerPlayer player, double radius) {
        List<Mob> mobs = level.getEntitiesOfClass(Mob.class, player.getBoundingBox().inflate(radius), m -> !isSpared(m));
        int changed = 0;
        for (Mob mob : mobs) {
            EntityType<?> type = CALM_POOL[level.random.nextInt(CALM_POOL.length)];
            for (int tries = 0; tries < 6 && type == mob.getType(); tries++) {
                type = CALM_POOL[level.random.nextInt(CALM_POOL.length)];
            }
            Entity replacement = type.create(level);
            if (replacement == null) {
                continue;
            }
            replacement.moveTo(mob.getX(), mob.getY(), mob.getZ(), mob.getYRot(), mob.getXRot());
            if (replacement instanceof Mob newMob) {
                newMob.finalizeSpawn(level, level.getCurrentDifficultyAt(mob.blockPosition()),
                        MobSpawnType.MOB_SUMMONED, null, null);
            }
            level.addFreshEntity(replacement);
            Vec3 middle = mob.position().add(0.0D, mob.getBbHeight() / 2.0D, 0.0D);
            Fx.burst(level, middle, Stone.REALITY.rgb, 40, 0.5D);
            level.sendParticles(ParticleTypes.END_ROD, middle.x, middle.y, middle.z, 20, 0.4D, 0.5D, 0.4D, 0.05D);
            mob.discard();
            changed++;
        }
        return changed;
    }

    /** Tap: every mob within 14 blocks becomes a random farm animal. */
    private boolean realityTransform(ServerLevel level, ServerPlayer player) {
        int changed = rewriteMobs(level, player, 14.0D);
        if (changed == 0) {
            return false;
        }
        Fx.ring(level, player.position().add(0.0D, 0.3D, 0.0D), 4.0D, Stone.REALITY.rgb, 30);
        Fx.sound(level, player.position(), SoundEvents.ENCHANTMENT_TABLE_USE, 1.5F, 0.8F);
        return true;
    }

    /** Charged: reality ripples outward, turning blocks into random treasure and mobs into animals. */
    private boolean realityRewrite(ServerLevel level, ServerPlayer player) {
        Vec3 center = player.pick(30.0D, 1.0F, false).getLocation();
        BlockPos origin = BlockPos.containing(center);
        rewriteMobs(level, player, 30.0D);
        for (int r = 1; r <= 6; r++) {
            final int radius = r;
            Scheduler.later(radius * 3, () -> {
                Fx.ring(level, center.add(0.0D, 0.3D, 0.0D), radius, Stone.REALITY.rgb, radius * 8);
                for (BlockPos pos : BlockPos.betweenClosed(origin.offset(-radius, -radius, -radius), origin.offset(radius, radius, radius))) {
                    double distance = Math.sqrt(pos.distSqr(origin));
                    if (distance > radius || distance <= radius - 1) {
                        continue;
                    }
                    BlockState state = level.getBlockState(pos);
                    if (state.isAir() || state.is(Blocks.BEDROCK) || state.hasBlockEntity() || !state.getFluidState().isEmpty()) {
                        continue;
                    }
                    level.setBlock(pos, CHAOS_BLOCKS[level.random.nextInt(CHAOS_BLOCKS.length)].defaultBlockState(), 3);
                }
            });
        }
        Fx.sound(level, center, SoundEvents.ENCHANTMENT_TABLE_USE, 2.0F, 0.5F);
        return true;
    }

    // =====================================================================
    // POWER
    // =====================================================================

    /** Tap: a purple beam that detonates along its whole length, ending in a huge blast. */
    private boolean powerBlast(ServerLevel level, ServerPlayer player) {
        Vec3 start = player.getEyePosition();
        Vec3 end = player.pick(48.0D, 1.0F, false).getLocation();
        Vec3 delta = end.subtract(start);
        double length = delta.length();
        Vec3 dir = delta.normalize();
        player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 100, 4, true, false));
        Fx.beam(level, start.add(dir.scale(1.5D)), end, Stone.POWER.rgb);
        Fx.sound(level, player.position(), SoundEvents.WARDEN_SONIC_BOOM, 2.0F, 1.0F);

        int steps = (int) (length / 5.0D);
        for (int i = 1; i <= steps; i++) {
            final Vec3 point = start.add(dir.scale(i * 5.0D));
            Scheduler.later(i, () -> level.explode(player, point.x, point.y, point.z, 3.5F, Level.ExplosionInteraction.TNT));
        }
        Scheduler.later(steps + 2, () -> {
            level.explode(player, end.x, end.y, end.z, 8.0F, Level.ExplosionInteraction.TNT);
            Fx.burst(level, end, Stone.POWER.rgb, 150, 2.5D);
            Fx.ring(level, end.add(0.0D, 0.3D, 0.0D), 8.0D, Stone.POWER.rgb, 60);
            for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, new AABB(end, end).inflate(10.0D), x -> x != player)) {
                e.hurt(level.damageSources().playerAttack(player), 30.0F);
                Vec3 away = e.position().subtract(end);
                Vec3 push = new Vec3(away.x, 0.0D, away.z).normalize();
                e.setDeltaMovement(push.x * 1.5D, 0.7D, push.z * 1.5D);
                e.hurtMarked = true;
            }
        });
        return true;
    }

    /** Charged: an orbital strike. A beam falls from the sky and the ground is erased. */
    private boolean powerAnnihilation(ServerLevel level, ServerPlayer player) {
        Vec3 center = player.pick(80.0D, 1.0F, false).getLocation();
        player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 200, 4, true, false));
        Fx.sound(level, center, SoundEvents.BEACON_ACTIVATE, 3.0F, 0.5F);

        for (int t = 0; t < 40; t += 2) {
            final int tick = t;
            Scheduler.later(t + 1, () -> {
                Fx.ring(level, center.add(0.0D, 0.2D, 0.0D), 12.0D - tick * 0.2D, Stone.POWER.rgb, 40);
                if (tick % 6 == 0) {
                    Fx.beam(level, center.add(0.0D, 30.0D, 0.0D), center, Stone.POWER.rgb);
                }
            });
        }

        Scheduler.later(45, () -> {
            level.explode(player, center.x, center.y, center.z, 12.0F, Level.ExplosionInteraction.TNT);
            Fx.burst(level, center, Stone.POWER.rgb, 300, 4.0D);
            Fx.ring(level, center.add(0.0D, 0.3D, 0.0D), 12.0D, Stone.POWER.rgb, 80);
            Fx.sound(level, center, SoundEvents.GENERIC_EXPLODE, 4.0F, 0.5F);
            for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, new AABB(center, center).inflate(24.0D), x -> !(x instanceof Player))) {
                e.hurt(level.damageSources().playerAttack(player), 60.0F);
            }
        });
        for (int i = 1; i <= 8; i++) {
            Scheduler.later(48 + i * 3, () -> {
                double x = center.x + (level.random.nextDouble() - 0.5D) * 28.0D;
                double z = center.z + (level.random.nextDouble() - 0.5D) * 28.0D;
                level.explode(player, x, center.y, z, 5.0F, Level.ExplosionInteraction.TNT);
            });
        }
        return true;
    }

    // =====================================================================
    // SOUL
    // =====================================================================

    /** Tap: full heal, cleanse, regeneration and absorption. */
    private boolean soulHeal(ServerLevel level, ServerPlayer player) {
        player.removeAllEffects();
        player.setHealth(player.getMaxHealth());
        player.getFoodData().setFoodLevel(20);
        player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 200, 2));
        player.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 1200, 4));
        for (int i = 0; i < 10; i++) {
            final int step = i;
            Scheduler.later(1 + i, () -> Fx.ring(level, player.position().add(0.0D, step * 0.2D, 0.0D), 1.0D, Stone.SOUL.rgb, 16));
        }
        level.sendParticles(ParticleTypes.HEART, player.getX(), player.getY() + 1.0D, player.getZ(), 20, 0.5D, 0.8D, 0.5D, 0.1D);
        Fx.sound(level, player.position(), SoundEvents.PLAYER_LEVELUP, 1.0F, 1.0F);
        return true;
    }

    /** Charged: drain life from every hostile mob nearby, heal yourself, pets and allies. */
    private boolean soulDrain(ServerLevel level, ServerPlayer player) {
        List<Mob> enemies = level.getEntitiesOfClass(Mob.class, player.getBoundingBox().inflate(14.0D),
                m -> m instanceof Enemy && !isSpared(m));
        float healed = 0.0F;
        for (Mob enemy : enemies) {
            enemy.hurt(level.damageSources().playerAttack(player), 14.0F);
            healed += 7.0F;
            Fx.beam(level, enemy.position().add(0.0D, enemy.getBbHeight() / 2.0D, 0.0D),
                    player.position().add(0.0D, 1.0D, 0.0D), Stone.SOUL.rgb);
        }
        boolean helpedAlly = false;
        for (LivingEntity ally : level.getEntitiesOfClass(LivingEntity.class, player.getBoundingBox().inflate(14.0D))) {
            if (ally instanceof TamableAnimal pet && pet.isTame()) {
                pet.heal(20.0F);
                helpedAlly = true;
            } else if (ally instanceof Player other && other != player) {
                other.heal(10.0F);
                helpedAlly = true;
            }
        }
        if (enemies.isEmpty() && !helpedAlly) {
            return false;
        }
        player.heal(Math.min(healed, 40.0F));
        level.sendParticles(ParticleTypes.SOUL, player.getX(), player.getY() + 1.0D, player.getZ(), 40, 0.6D, 0.8D, 0.6D, 0.05D);
        Fx.sound(level, player.position(), SoundEvents.SOUL_ESCAPE, 2.0F, 0.8F);
        return true;
    }

    // =====================================================================
    // TIME
    // =====================================================================

    /** Tap: freeze everything within 24 blocks for 8 seconds while you speed up. */
    private boolean timeStasis(ServerLevel level, ServerPlayer player) {
        List<LivingEntity> targets = level.getEntitiesOfClass(LivingEntity.class, player.getBoundingBox().inflate(24.0D),
                e -> !(e instanceof Player));
        if (targets.isEmpty()) {
            return false;
        }
        for (LivingEntity e : targets) {
            e.addEffect(new MobEffectInstance(ModEffects.TIME_STASIS.get(), e instanceof ThorEntity ? 60 : 160, 0));
        }
        player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 160, 2));
        player.addEffect(new MobEffectInstance(MobEffects.DIG_SPEED, 160, 2));
        Fx.ring(level, player.position().add(0.0D, 0.2D, 0.0D), 6.0D, Stone.TIME.rgb, 50);
        Fx.sound(level, player.position(), SoundEvents.BEACON_DEACTIVATE, 2.0F, 0.6F);
        return true;
    }

    /** Charged: rewind yourself to where you stood about 5 seconds ago, freezing nearby mobs. */
    private boolean timeRewind(ServerLevel level, ServerPlayer player) {
        ArrayDeque<Snapshot> history = HISTORY.get(player.getUUID());
        if (history == null || history.size() < 4) {
            return false;
        }
        Snapshot past = history.peekFirst();
        if (past == null || !past.dimension().equals(level.dimension())) {
            return false;
        }
        for (Mob mob : level.getEntitiesOfClass(Mob.class, player.getBoundingBox().inflate(16.0D), m -> !isSpared(m))) {
            mob.addEffect(new MobEffectInstance(ModEffects.TIME_STASIS.get(), 60, 0));
        }
        Fx.ring(level, player.position().add(0.0D, 0.2D, 0.0D), 1.5D, Stone.TIME.rgb, 24);
        Fx.burst(level, player.position().add(0.0D, 1.0D, 0.0D), Stone.TIME.rgb, 60, 0.6D);
        player.connection.teleport(past.x(), past.y(), past.z(), past.yRot(), past.xRot());
        player.fallDistance = 0.0F;
        player.setHealth(Math.max(player.getHealth(), Math.min(past.health(), player.getMaxHealth())));
        history.clear();
        Vec3 landing = new Vec3(past.x(), past.y(), past.z());
        Fx.ring(level, landing.add(0.0D, 0.2D, 0.0D), 1.5D, Stone.TIME.rgb, 24);
        Fx.burst(level, landing.add(0.0D, 1.0D, 0.0D), Stone.TIME.rgb, 60, 0.6D);
        Fx.sound(level, landing, SoundEvents.BEACON_POWER_SELECT, 2.0F, 0.5F);
        return true;
    }

    // =====================================================================
    // THE SNAP
    // =====================================================================

    /** Half of all mobs in this dimension turn to ash. The gauntlet burns you for it. */
    private boolean snap(ServerLevel level, ServerPlayer player) {
        List<Mob> everyone = new ArrayList<>();
        for (Entity e : level.getAllEntities()) {
            if (e instanceof Mob mob && mob.isAlive() && !isSpared(mob)) {
                everyone.add(mob);
            }
        }
        if (everyone.isEmpty()) {
            return false;
        }
        int doomed = 0;
        for (Mob mob : everyone) {
            if (level.random.nextBoolean()) {
                doomed++;
                Scheduler.later(5 + level.random.nextInt(60), () -> {
                    if (mob.isAlive()) {
                        level.sendParticles(ParticleTypes.ASH, mob.getX(), mob.getY(0.5D), mob.getZ(), 60, 0.4D, 0.6D, 0.4D, 0.08D);
                        level.sendParticles(Fx.dust(0x555555, 1.6F), mob.getX(), mob.getY(0.5D), mob.getZ(), 25, 0.4D, 0.6D, 0.4D, 0.05D);
                        mob.discard();
                    }
                });
            }
        }
        for (Stone stone : Stone.values()) {
            Fx.ring(level, player.position().add(0.0D, 0.3D + stone.ordinal() * 0.3D, 0.0D), 2.0D, stone.rgb, 30);
        }
        Fx.sound(level, player.position(), SoundEvents.LIGHTNING_BOLT_THUNDER, 3.0F, 0.5F);
        player.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 600, 1));
        player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 600, 1));
        player.addEffect(new MobEffectInstance(MobEffects.HUNGER, 600, 1));
        player.getCooldowns().addCooldown(this, 6000);
        player.displayClientMessage(Component.translatable("message.thanosmod.snapped", doomed)
                .withStyle(ChatFormatting.GOLD), false);
        return true;
    }
}
