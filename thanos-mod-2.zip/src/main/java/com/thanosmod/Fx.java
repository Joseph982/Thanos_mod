package com.thanosmod;

import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

/** Small helpers for the mod's own coloured particle effects, sounds and lightning. */
public final class Fx {
    private Fx() {
    }

    public static DustParticleOptions dust(int rgb, float size) {
        return new DustParticleOptions(new Vector3f(
                ((rgb >> 16) & 255) / 255.0F,
                ((rgb >> 8) & 255) / 255.0F,
                (rgb & 255) / 255.0F), size);
    }

    public static void ring(ServerLevel level, Vec3 center, double radius, int rgb, int points) {
        DustParticleOptions options = dust(rgb, 1.4F);
        for (int i = 0; i < points; i++) {
            double angle = Math.PI * 2.0D * i / points;
            level.sendParticles(options, center.x + Math.cos(angle) * radius, center.y,
                    center.z + Math.sin(angle) * radius, 1, 0.0D, 0.0D, 0.0D, 0.0D);
        }
    }

    public static void burst(ServerLevel level, Vec3 center, int rgb, int count, double spread) {
        level.sendParticles(dust(rgb, 1.6F), center.x, center.y, center.z, count, spread, spread, spread, 0.02D);
    }

    public static void beam(ServerLevel level, Vec3 from, Vec3 to, int rgb) {
        Vec3 delta = to.subtract(from);
        double length = delta.length();
        if (length < 0.1D) {
            return;
        }
        Vec3 step = delta.normalize().scale(0.6D);
        int count = (int) (length / 0.6D);
        DustParticleOptions options = dust(rgb, 1.8F);
        Vec3 point = from;
        for (int i = 0; i < count; i++) {
            level.sendParticles(options, point.x, point.y, point.z, 1, 0.0D, 0.0D, 0.0D, 0.0D);
            point = point.add(step);
        }
    }

    public static void sound(ServerLevel level, Vec3 pos, SoundEvent sound, float volume, float pitch) {
        level.playSound(null, pos.x, pos.y, pos.z, sound, SoundSource.PLAYERS, volume, pitch);
    }

    /** Real lightning. If a player caused it, they get a moment of fire protection. */
    public static void strike(ServerLevel level, Vec3 pos, ServerPlayer cause) {
        LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(level);
        if (bolt == null) {
            return;
        }
        bolt.moveTo(pos);
        if (cause != null) {
            bolt.setCause(cause);
            cause.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 100, 0, true, false));
        }
        level.addFreshEntity(bolt);
    }
}
