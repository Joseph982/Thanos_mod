package com.thanosmod;

import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * Thor, God of Thunder (boss).
 * Phase 1: melee with Mjolnir, plus telegraphed lightning strikes on his target.
 * Phase 2 (under 66% health): faster, and leaps into the air to slam the ground.
 * Phase 3 (under 33% health): summons a thunderstorm and rains lightning.
 * He is immune to lightning, and drops Mjolnir.
 */
public class ThorEntity extends Monster {
    private final ServerBossEvent bossEvent = new ServerBossEvent(
            Component.translatable("entity.thanosmod.thor"),
            BossEvent.BossBarColor.BLUE, BossEvent.BossBarOverlay.PROGRESS);

    private int abilityTick;
    private Vec3 strikeTarget;
    private int strikeAt = -1;
    private int slamAt = -1;
    private boolean phase2;
    private boolean phase3;

    public ThorEntity(EntityType<? extends ThorEntity> type, Level level) {
        super(type, level);
        this.xpReward = 200;
        this.setPersistenceRequired();
        this.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(ModItems.MJOLNIR.get()));
        this.setDropChance(EquipmentSlot.MAINHAND, 0.0F);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 300.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.30D)
                .add(Attributes.ATTACK_DAMAGE, 14.0D)
                .add(Attributes.FOLLOW_RANGE, 48.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.9D)
                .add(Attributes.ARMOR, 10.0D);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.15D, false));
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.8D));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 16.0F));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    // ---------- boss bar ----------

    @Override
    public void startSeenByPlayer(ServerPlayer player) {
        super.startSeenByPlayer(player);
        bossEvent.addPlayer(player);
    }

    @Override
    public void stopSeenByPlayer(ServerPlayer player) {
        super.stopSeenByPlayer(player);
        bossEvent.removePlayer(player);
    }

    @Override
    public void remove(Entity.RemovalReason reason) {
        super.remove(reason);
        bossEvent.removeAllPlayers();
    }

    // ---------- the fight ----------

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        bossEvent.setProgress(this.getHealth() / this.getMaxHealth());
        if (!(this.level() instanceof ServerLevel server)) {
            return;
        }

        // a telegraphed strike: a glowing ring warns you, then the bolt lands
        if (strikeAt >= 0 && strikeTarget != null) {
            Fx.ring(server, strikeTarget.add(0.0D, 0.2D, 0.0D), 1.5D, 0x8FD3FF, 14);
            if (this.tickCount >= strikeAt) {
                Fx.strike(server, strikeTarget, null);
                strikeAt = -1;
                strikeTarget = null;
            }
        }

        // the ground slam lands
        if (slamAt >= 0 && this.tickCount >= slamAt) {
            slam(server);
            slamAt = -1;
        }

        LivingEntity target = this.getTarget();
        if (target == null || !target.isAlive()) {
            abilityTick = 0;
            return;
        }
        abilityTick++;
        float health = this.getHealth() / this.getMaxHealth();

        if (health < 0.66F && !phase2) {
            phase2 = true;
            shout(server, "message.thanosmod.thor_phase2");
            this.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 1000000, 0, true, false));
        }
        if (health < 0.33F && !phase3) {
            phase3 = true;
            shout(server, "message.thanosmod.thor_phase3");
            server.setWeatherParameters(0, 6000, true, true);
            this.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 1000000, 1, true, false));
        }

        int thunderEvery = phase3 ? 40 : (phase2 ? 60 : 90);
        if (abilityTick % thunderEvery == 0 && strikeAt < 0) {
            strikeTarget = target.position();
            strikeAt = this.tickCount + 20;
            this.playSound(SoundEvents.LIGHTNING_BOLT_THUNDER, 1.0F, 1.4F);
        }

        if (phase2 && abilityTick % 140 == 70 && slamAt < 0) {
            startSlam(target);
        }

        if (phase3 && abilityTick % 30 == 0) {
            double x = target.getX() + (this.random.nextDouble() - 0.5D) * 12.0D;
            double z = target.getZ() + (this.random.nextDouble() - 0.5D) * 12.0D;
            Fx.strike(server, new Vec3(x, target.getY(), z), null);
        }
    }

    private void startSlam(LivingEntity target) {
        Vec3 flat = target.position().subtract(this.position());
        Vec3 dir = new Vec3(flat.x, 0.0D, flat.z).normalize();
        this.setDeltaMovement(dir.x * 0.9D, 1.0D, dir.z * 0.9D);
        this.hasImpulse = true;
        slamAt = this.tickCount + 20;
        this.playSound(SoundEvents.ENDER_DRAGON_FLAP, 2.0F, 0.8F);
    }

    private void slam(ServerLevel server) {
        Vec3 center = this.position();
        Fx.ring(server, center.add(0.0D, 0.2D, 0.0D), 2.0D, 0xFFFFFF, 20);
        Fx.ring(server, center.add(0.0D, 0.2D, 0.0D), 4.0D, 0x8FD3FF, 32);
        Fx.ring(server, center.add(0.0D, 0.2D, 0.0D), 6.0D, 0x3A7BD5, 44);
        server.sendParticles(ParticleTypes.EXPLOSION_EMITTER, center.x, center.y + 0.5D, center.z, 1, 0.0D, 0.0D, 0.0D, 0.0D);
        server.playSound(null, center.x, center.y, center.z, SoundEvents.GENERIC_EXPLODE, SoundSource.HOSTILE, 3.0F, 0.7F);
        for (LivingEntity e : server.getEntitiesOfClass(LivingEntity.class, this.getBoundingBox().inflate(7.0D),
                x -> x != this && !(x instanceof ThorEntity))) {
            Vec3 away = e.position().subtract(center);
            Vec3 push = new Vec3(away.x, 0.0D, away.z).normalize();
            e.hurt(this.damageSources().mobAttack(this), 16.0F);
            e.setDeltaMovement(push.x * 1.4D, 0.8D, push.z * 1.4D);
            e.hurtMarked = true;
            e.addEffect(new MobEffectInstance(ModEffects.THUNDERSTRUCK.get(), 80, 0));
        }
        for (int i = 0; i < 4; i++) {
            double angle = Math.PI / 2.0D * i + Math.PI / 4.0D;
            Fx.strike(server, center.add(Math.cos(angle) * 5.0D, 0.0D, Math.sin(angle) * 5.0D), null);
        }
    }

    private void shout(ServerLevel server, String key) {
        for (Player player : server.getEntitiesOfClass(Player.class, this.getBoundingBox().inflate(48.0D))) {
            player.displayClientMessage(Component.translatable(key).withStyle(ChatFormatting.AQUA, ChatFormatting.BOLD), false);
        }
    }

    @Override
    public boolean doHurtTarget(Entity target) {
        boolean hit = super.doHurtTarget(target);
        if (hit && target instanceof LivingEntity living && this.level() instanceof ServerLevel server) {
            living.addEffect(new MobEffectInstance(ModEffects.THUNDERSTRUCK.get(), 100, 0));
            if (this.random.nextFloat() < 0.3F) {
                Fx.strike(server, target.position(), null);
            }
        }
        return hit;
    }

    /** Thor commands the lightning, so it cannot hurt him. */
    @Override
    public void thunderHit(ServerLevel level, LightningBolt bolt) {
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (this.level().isClientSide && this.random.nextInt(3) == 0) {
            this.level().addParticle(ParticleTypes.ELECTRIC_SPARK,
                    this.getRandomX(0.5D), this.getRandomY(), this.getRandomZ(0.5D), 0.0D, 0.0D, 0.0D);
        }
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.PILLAGER_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.PILLAGER_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.PILLAGER_DEATH;
    }
}
