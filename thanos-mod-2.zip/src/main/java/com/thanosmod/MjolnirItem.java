package com.thanosmod;

import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.Tiers;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.List;

/**
 * Mjolnir. Only the worthy can wield it (20+ XP levels, or creative).
 * Tap right-click: call lightning where you look.
 * Hold right-click about 1 second: fly forward like Thor.
 * Sneak + right-click: call a lightning storm.
 * Every hit shocks the target and sometimes calls lightning.
 */
public class MjolnirItem extends SwordItem {
    private static final int FLIGHT_CHARGE = 15;

    public MjolnirItem(Properties properties) {
        super(Tiers.NETHERITE, 7, -2.8F, properties);
    }

    public static boolean isWorthy(Player player) {
        return player.isCreative() || player.experienceLevel >= 20;
    }

    // The hammer never breaks (no @Override on purpose, harmless if the method is named differently).
    public boolean isDamageable(ItemStack stack) {
        return false;
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return true;
    }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.thanosmod.mjolnir_worthy").withStyle(ChatFormatting.AQUA));
        tooltip.add(Component.translatable("tooltip.thanosmod.mjolnir_tap").withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable("tooltip.thanosmod.mjolnir_hold").withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable("tooltip.thanosmod.mjolnir_storm").withStyle(ChatFormatting.GRAY));
    }

    @Override
    public boolean hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        if (attacker instanceof ServerPlayer player && isWorthy(player) && target.level() instanceof ServerLevel level) {
            target.addEffect(new MobEffectInstance(ModEffects.THUNDERSTRUCK.get(), 100, 0));
            if (level.random.nextFloat() < 0.35F) {
                Fx.strike(level, target.position(), player);
            }
        }
        return super.hurtEnemy(stack, target, attacker);
    }

    @Override
    public void inventoryTick(ItemStack stack, Level level, Entity entity, int slot, boolean selected) {
        super.inventoryTick(stack, level, entity, slot, selected);
        if (!level.isClientSide && selected && entity instanceof Player player
                && !isWorthy(player) && player.tickCount % 20 == 0) {
            // the hammer is far too heavy for the unworthy
            player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 2, true, true));
            player.addEffect(new MobEffectInstance(MobEffects.DIG_SLOWDOWN, 60, 2, true, true));
        }
    }

    @Override
    public UseAnim getUseAnimation(ItemStack stack) {
        return UseAnim.SPEAR;
    }

    @Override
    public int getUseDuration(ItemStack stack) {
        return 72000;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!isWorthy(player)) {
            if (!level.isClientSide) {
                player.displayClientMessage(
                        Component.translatable("message.thanosmod.unworthy").withStyle(ChatFormatting.RED), true);
            }
            return InteractionResultHolder.fail(stack);
        }
        if (player.isShiftKeyDown()) {
            if (!level.isClientSide) {
                stormCall((ServerLevel) level, (ServerPlayer) player);
            }
            return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
        }
        player.startUsingItem(hand);
        return InteractionResultHolder.consume(stack);
    }

    @Override
    public void releaseUsing(ItemStack stack, Level level, LivingEntity living, int timeLeft) {
        if (level.isClientSide || !(living instanceof ServerPlayer player) || !isWorthy(player)) {
            return;
        }
        ServerLevel server = (ServerLevel) level;
        int charge = getUseDuration(stack) - timeLeft;
        if (charge >= FLIGHT_CHARGE) {
            flight(server, player);
            player.getCooldowns().addCooldown(this, 60);
        } else {
            callLightning(server, player);
            player.getCooldowns().addCooldown(this, 20);
        }
    }

    private void callLightning(ServerLevel level, ServerPlayer player) {
        Vec3 point = player.pick(64.0D, 1.0F, false).getLocation();
        Fx.strike(level, point, player);
        Fx.ring(level, point.add(0.0D, 0.2D, 0.0D), 3.0D, 0x8FD3FF, 24);
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, new AABB(point, point).inflate(4.0D), x -> x != player)) {
            e.hurt(level.damageSources().playerAttack(player), 14.0F);
            e.addEffect(new MobEffectInstance(ModEffects.THUNDERSTRUCK.get(), 120, 0));
        }
    }

    private void flight(ServerLevel level, ServerPlayer player) {
        Vec3 look = player.getLookAngle();
        Fx.strike(level, player.position(), player);
        player.setDeltaMovement(look.scale(2.4D).add(0.0D, 0.3D, 0.0D));
        player.hurtMarked = true;
        player.fallDistance = 0.0F;
        player.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 100, 0, true, false));
        Fx.sound(level, player.position(), SoundEvents.LIGHTNING_BOLT_THUNDER, 1.5F, 1.2F);
        for (int i = 0; i < 12; i++) {
            Scheduler.later(1 + i * 2, () -> {
                level.sendParticles(ParticleTypes.ELECTRIC_SPARK, player.getX(), player.getY() + 1.0D, player.getZ(),
                        14, 0.4D, 0.6D, 0.4D, 0.15D);
                Fx.burst(level, player.position().add(0.0D, 1.0D, 0.0D), 0x8FD3FF, 8, 0.4D);
            });
        }
    }

    private void stormCall(ServerLevel level, ServerPlayer player) {
        if (player.getCooldowns().isOnCooldown(this)) {
            return;
        }
        Vec3 center = player.pick(48.0D, 1.0F, false).getLocation();
        level.setWeatherParameters(0, 3000, true, true);
        for (int i = 0; i < 12; i++) {
            Scheduler.later(2 + i * 4, () -> {
                double x = center.x + (level.random.nextDouble() - 0.5D) * 16.0D;
                double z = center.z + (level.random.nextDouble() - 0.5D) * 16.0D;
                double y = level.getHeight(Heightmap.Types.MOTION_BLOCKING, (int) Math.floor(x), (int) Math.floor(z));
                Fx.strike(level, new Vec3(x, y, z), player);
            });
        }
        player.getCooldowns().addCooldown(this, 240);
    }
}
