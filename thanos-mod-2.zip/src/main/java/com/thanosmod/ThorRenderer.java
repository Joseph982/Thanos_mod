package com.thanosmod;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.resources.ResourceLocation;

public class ThorRenderer extends HumanoidMobRenderer<ThorEntity, HumanoidModel<ThorEntity>> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(ThanosMod.MODID, "textures/entity/thor.png");

    public ThorRenderer(EntityRendererProvider.Context context) {
        super(context, new HumanoidModel<>(context.bakeLayer(ModelLayers.PLAYER)), 0.6F);
    }

    @Override
    protected void scale(ThorEntity entity, PoseStack poseStack, float partialTick) {
        poseStack.scale(1.2F, 1.2F, 1.2F);
    }

    @Override
    public ResourceLocation getTextureLocation(ThorEntity entity) {
        return TEXTURE;
    }
}
