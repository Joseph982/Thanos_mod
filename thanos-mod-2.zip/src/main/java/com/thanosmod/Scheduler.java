package com.thanosmod;

import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/** Runs things a few ticks later (used for beams, delayed blasts, the Snap...). */
@Mod.EventBusSubscriber(modid = ThanosMod.MODID)
public final class Scheduler {
    private static final List<Task> TASKS = new ArrayList<>();

    private static final class Task {
        int ticks;
        final Runnable run;

        Task(int ticks, Runnable run) {
            this.ticks = ticks;
            this.run = run;
        }
    }

    private Scheduler() {
    }

    public static void later(int ticks, Runnable run) {
        TASKS.add(new Task(Math.max(1, ticks), run));
    }

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || TASKS.isEmpty()) {
            return;
        }
        List<Task> due = new ArrayList<>();
        Iterator<Task> it = TASKS.iterator();
        while (it.hasNext()) {
            Task task = it.next();
            task.ticks--;
            if (task.ticks <= 0) {
                due.add(task);
                it.remove();
            }
        }
        for (Task task : due) {
            try {
                task.run.run();
            } catch (RuntimeException ignored) {
                // a delayed effect must never crash the server
            }
        }
    }
}
