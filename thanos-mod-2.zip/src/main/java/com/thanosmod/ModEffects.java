package com.thanosmod;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/** The mod's own potion effects (with their own icons). */
public class ModEffects {
    public static final DeferredRegister<MobEffect> EFFECTS =
            DeferredRegister.create(ForgeRegistries.MOB_EFFECTS, ThanosMod.MODID);

    public static final RegistryObject<MobEffect> TIME_STASIS = EFFECTS.register("time_stasis", TimeStasis::new);
    public static final RegistryObject<MobEffect> MIND_CONTROL = EFFECTS.register("mind_control", MindControl::new);
    public static final RegistryObject<MobEffect> POWER_SURGE = EFFECTS.register("power_surge", PowerSurge::new);
    public static final RegistryObject<MobEffect> THUNDERSTRUCK = EFFECTS.register("thunderstruck", Thunderstruck::new);

    /** Frozen in time: cannot move, jump or hit. */
    public static class TimeStasis extends MobEffect {
        public TimeStasis() {
            super(MobEffectCategory.HARMFUL, 0x32D250);
            addAttributeModifier(Attributes.MOVEMENT_SPEED, "6F1E2C48-1A52-4B7D-9C31-2D8B6E5F0A11",
                    -1.0D, AttributeModifier.Operation.MULTIPLY_TOTAL);
            addAttributeModifier(Attributes.ATTACK_DAMAGE, "A4C3D2E1-5B6F-4A87-8D90-1E2F3A4B5C6D",
                    -1.0D, AttributeModifier.Operation.MULTIPLY_TOTAL);
        }

        @Override
        public boolean isDurationEffectTick(int duration, int amplifier) {
            return true;
        }

        @Override
        public void applyEffectTick(LivingEntity entity, int amplifier) {
            entity.setDeltaMovement(Vec3.ZERO);
            entity.fallDistance = 0.0F;
            if (entity instanceof Mob mob) {
                mob.getNavigation().stop();
            }
            if (entity.tickCount % 6 == 0 && entity.level() instanceof ServerLevel level) {
                Fx.ring(level, entity.position().add(0.0D, entity.getBbHeight() / 2.0D, 0.0D), 0.8D, 0x32D250, 8);
            }
        }
    }

    /** Mobs with this effect keep attacking their nearest neighbour. */
    public static class MindControl extends MobEffect {
        public MindControl() {
            super(MobEffectCategory.HARMFUL, 0xFFE23B);
        }

        @Override
        public boolean isDurationEffectTick(int duration, int amplifier) {
            return duration % 10 == 0;
        }

        @Override
        public void applyEffectTick(LivingEntity entity, int amplifier) {
            if (entity instanceof Mob mob && entity.level() instanceof ServerLevel level) {
                Mob nearest = null;
                double best = 400.0D;
                for (Mob other : level.getEntitiesOfClass(Mob.class, mob.getBoundingBox().inflate(20.0D), x -> x != mob)) {
                    double d = mob.distanceToSqr(other);
                    if (d < best) {
                        best = d;
                        nearest = other;
                    }
                }
                if (nearest != null) {
                    mob.setTarget(nearest);
                }
                Fx.burst(level, mob.position().add(0.0D, mob.getBbHeight() + 0.3D, 0.0D), 0xFFE23B, 2, 0.15D);
            }
        }
    }

    /** More damage, speed and armor, with a purple aura. */
    public static class PowerSurge extends MobEffect {
        public PowerSurge() {
            super(MobEffectCategory.BENEFICIAL, 0xA03CE6);
            addAttributeModifier(Attributes.ATTACK_DAMAGE, "0B9E8D7C-6A5F-4E3D-8C2B-1A0F9E8D7C6B",
                    4.0D, AttributeModifier.Operation.ADDITION);
            addAttributeModifier(Attributes.MOVEMENT_SPEED, "3C4D5E6F-7A8B-4C9D-A0E1-F2A3B4C5D6E7",
                    0.15D, AttributeModifier.Operation.MULTIPLY_TOTAL);
            addAttributeModifier(Attributes.ARMOR, "9A8B7C6D-5E4F-4A3B-8C2D-1E0F9A8B7C6D",
                    4.0D, AttributeModifier.Operation.ADDITION);
        }

        @Override
        public boolean isDurationEffectTick(int duration, int amplifier) {
            return duration % 8 == 0;
        }

        @Override
        public void applyEffectTick(LivingEntity entity, int amplifier) {
            if (entity.level() instanceof ServerLevel level) {
                Fx.ring(level, entity.position().add(0.0D, 0.1D, 0.0D), 0.7D, 0xA03CE6, 10);
            }
        }
    }

    /** Hit by Mjolnir or Thor: slowed and shocked over time. Thor himself is immune. */
    public static class Thunderstruck extends MobEffect {
        public Thunderstruck() {
            super(MobEffectCategory.HARMFUL, 0xFFF08A);
            addAttributeModifier(Attributes.MOVEMENT_SPEED, "1D2E3F4A-5B6C-4D7E-8F90-A1B2C3D4E5F6",
                    -0.25D, AttributeModifier.Operation.MULTIPLY_TOTAL);
        }

        @Override
        public boolean isDurationEffectTick(int duration, int amplifier) {
            return duration % 10 == 0;
        }

        @Override
        public void applyEffectTick(LivingEntity entity, int amplifier) {
            if (entity instanceof ThorEntity) {
                return;
            }
            entity.hurt(entity.damageSources().magic(), 1.0F + amplifier);
            if (entity.level() instanceof ServerLevel level) {
                level.sendParticles(ParticleTypes.ELECTRIC_SPARK, entity.getX(), entity.getY() + entity.getBbHeight() / 2.0D,
                        entity.getZ(), 6, 0.3D, 0.5D, 0.3D, 0.1D);
            }
        }
    }
}
