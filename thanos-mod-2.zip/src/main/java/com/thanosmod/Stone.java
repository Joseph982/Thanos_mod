package com.thanosmod;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;

public enum Stone {
    SPACE("space", ChatFormatting.BLUE, 0x3A6EFF),
    MIND("mind", ChatFormatting.YELLOW, 0xFFE23B),
    REALITY("reality", ChatFormatting.RED, 0xE62323),
    POWER("power", ChatFormatting.DARK_PURPLE, 0xA03CE6),
    SOUL("soul", ChatFormatting.GOLD, 0xFF8C14),
    TIME("time", ChatFormatting.GREEN, 0x32D250);

    public final String id;
    public final ChatFormatting color;
    public final int rgb;

    Stone(String id, ChatFormatting color, int rgb) {
        this.id = id;
        this.color = color;
        this.rgb = rgb;
    }

    public Item item() {
        return ModItems.STONES.get(this).get();
    }

    public Component displayName() {
        return Component.translatable("item.thanosmod." + id + "_stone").withStyle(color);
    }
}
