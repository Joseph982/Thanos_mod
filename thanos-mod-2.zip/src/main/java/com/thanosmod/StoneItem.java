package com.thanosmod;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import java.util.List;

public class StoneItem extends Item {
    private final Stone stone;

    public StoneItem(Stone stone, Properties properties) {
        super(properties);
        this.stone = stone;
    }

    public Stone getStone() {
        return stone;
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return true;
    }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.thanosmod." + stone.id + ".tap").withStyle(stone.color));
        tooltip.add(Component.translatable("tooltip.thanosmod." + stone.id + ".charged").withStyle(stone.color));
        tooltip.add(Component.translatable("tooltip.thanosmod.stone_hint").withStyle(ChatFormatting.DARK_GRAY));
    }
}
